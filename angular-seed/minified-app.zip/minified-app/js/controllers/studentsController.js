app.controller('studentsController', function ($scope) {
    $scope.people = [
        {
            "name": "Pesho",
            "photo": "http://www.nakov.com/wp-content/uploads/2014/05/SoftUni-Logo.png",
            "grade": 6,
            "school": "High School of Mathematics",
            "teacher": "Gichka Pesheva",
        },
        {
            "name": "Gosho",
            "photo": "http://www.nakov.com/wp-content/uploads/2014/05/SoftUni-Logo.png",
            "grade": 5,
            "school": "High School of Economics",
            "teacher": "Gichka Pesheva",
        },
        {
            "name": "Tosho",
            "photo": "http://www.nakov.com/wp-content/uploads/2014/05/SoftUni-Logo.png",
            "grade": 4,
            "school": "High School of Physics",
            "teacher": "Gichka Pesheva",
        }
    ]
});